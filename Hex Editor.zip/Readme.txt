How to use Crack:

Copy & Replace the fixed files to the folder where you installed the product.



-------------------------

How to Patch

If the "fix" is "patch" copy it to the folder where you have installed the program and run it as admin to register.




--------------------------

How to use Keygen

	 1. Install the application
     2. Generate a serial
     3. Register the app
	 4. As always, make sure to have a firewall to block outbound connections.